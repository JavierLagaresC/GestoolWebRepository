package com.gestool.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.gestool.model.Empresa;
import com.gestool.model.Usuario;
import com.gestool.repository.UsuarioRepository;

@Service
public class UsuarioService {

	
	@Autowired
	UsuarioRepository usuarioRepo;
	
	public Usuario loginByEmailAndPassword(String email, String password) {
		
		Usuario usuario = usuarioRepo.findFirstByEmailAndPassword(email, password);
		
		return usuario;
		
	}
	
	public List<Usuario> findAllUsuarios() {
		return usuarioRepo.findAll();
	}
	
	public Usuario findById(Long id) {
		return usuarioRepo.getOne(id);
	}
	
	public void add(Usuario usuario) {
		usuarioRepo.save(usuario);
	}
	
	public void deleteUsuario(Long id) {
		usuarioRepo.delete(usuarioRepo.getOne(id));
	}

	
}

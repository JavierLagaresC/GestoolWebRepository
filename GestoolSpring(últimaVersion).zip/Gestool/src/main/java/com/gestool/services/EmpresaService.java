package com.gestool.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.gestool.model.Empresa;
import com.gestool.repository.EmpresaRepository;

@Service
public class EmpresaService {
	
	@Autowired
	EmpresaRepository empresaRepo;
	
	
	public List<Empresa> findAllEmpresas() {
		return empresaRepo.findAll();
	}
	
	public Empresa findById(Long id) {
		return empresaRepo.getOne(id);
	}
	
	public void add(Empresa empresa) {
		empresaRepo.save(empresa);
	}
	
	public void deleteEmpresa (Long id) {
		empresaRepo.delete(empresaRepo.getOne(id));
	}
	
}

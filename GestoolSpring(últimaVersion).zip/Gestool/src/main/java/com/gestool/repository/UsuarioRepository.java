package com.gestool.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.gestool.model.Usuario;

public interface UsuarioRepository extends JpaRepository<Usuario, Long>{

	public Usuario findFirstByEmailAndPassword(String email, String password);


	
}

package com.gestool.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.gestool.model.Empresa;

public interface EmpresaRepository extends JpaRepository<Empresa, Long>{


	
	
}

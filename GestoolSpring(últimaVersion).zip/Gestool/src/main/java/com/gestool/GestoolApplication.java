package com.gestool;

import javax.persistence.EntityManager;
import javax.servlet.Filter;

import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.web.servlet.FilterRegistrationBean;
import org.springframework.context.annotation.Bean;

import com.gestool.controller.SecurityFilter;
import com.gestool.model.Usuario;
import com.gestool.repository.UsuarioRepository;


@SpringBootApplication
public class GestoolApplication {

	public static void main(String[] args) {
		SpringApplication.run(GestoolApplication.class, args);
	}
	
	private EntityManager entityManager;

	
	/*@Bean
	public CommandLineRunner demoData(UsuarioRepository repo) {
		return (args) -> {
			if (repo.count() == 0) {
				Usuario usuario = new Usuario();
				usuario.setNombre("Javier Lagares Caceres");
				usuario.setEmail("admin@admin.admin");
				usuario.setPassword("admin");
				repo.save(usuario);
				usuario.setNombre("Javi");
				usuario.setEmail("usuario");
				usuario.setPassword("1234");
				repo.save(usuario);
			}
		};
	}*/
	
	
	@Bean
	public FilterRegistrationBean filterSecurityBean() {
		FilterRegistrationBean registration = new FilterRegistrationBean();
		registration.setFilter(securityFilter());
		registration.addUrlPatterns("/app/*");
		registration.setName("securityFilter");
		return registration;
	}
	
	@Bean(name="securityFilter")
	public Filter securityFilter() {
		return new SecurityFilter();
	}
	
}

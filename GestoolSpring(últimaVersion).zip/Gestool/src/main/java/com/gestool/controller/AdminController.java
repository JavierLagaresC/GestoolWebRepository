package com.gestool.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.gestool.model.Empresa;
import com.gestool.model.Usuario;
import com.gestool.services.UsuarioService;

@Controller
@RequestMapping("/app")
public class AdminController {

	@Autowired
	UsuarioService usuarioSE;
	
	
	@GetMapping("/usuarios")
	public String listar(Model model) {

		
		List<Usuario> result = usuarioSE.findAllUsuarios();
		model.addAttribute("list", result);
	
		return "Usuarios";
	}
	
	@GetMapping("/eliminarUsuario/{id}")
	public String eliminarEmpresa(@PathVariable("id")long id, Model model){
		usuarioSE.deleteUsuario(id);
		return "redirect:/app/usuarios";
	}
	
	
	@GetMapping("/formEditarUsuarios/{id}")
	public String FormularioEditarUsuarios(@PathVariable("id") Long id, Model model) {
		Usuario usuario = usuarioSE.findById(id);
		model.addAttribute("usuarioForm", usuario);
		return "formEditarUsuarios";
	}

	@PostMapping("/{id}/editarUsuario")
	public String submitEditarUsuario(@ModelAttribute("usuarioForm") Usuario usuario,BindingResult bindingResult, Model model) {
			
		usuarioSE.add(usuario);
		
		
		return "redirect:/app/usuarios";
	}
	
}

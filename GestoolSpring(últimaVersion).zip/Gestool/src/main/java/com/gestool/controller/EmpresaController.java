package com.gestool.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.gestool.model.Empresa;
import com.gestool.model.Usuario;
import com.gestool.repository.EmpresaRepository;
import com.gestool.services.EmpresaService;


@Controller
@RequestMapping("/app")
public class EmpresaController {

	@Autowired
	EmpresaService empresaSE;
	EmpresaRepository empresaRepo;
	
	
	@GetMapping("/empresas")
	public String listar(Model model, Usuario user) {

		/*if(user != null && user.getTipoUser() == 0) {
			return "redirect:/app/usuarioNormal";
		}else {*/
			List<Empresa> result = empresaSE.findAllEmpresas();
			model.addAttribute("list", result);
		
			return "Empresas";
		//}
		
		
	}
	
	
	@GetMapping("/addEmpresa")
	public String addForm(Model model, Usuario user) {
		
		/*if(user != null && user.getTipoUser() == 0) {
			return "redirect:/app/usuarioNormal";
		}else {*/
			Empresa empresa= new Empresa();
			model.addAttribute("empresaForm", empresa);
			return "addEmpresa";
		//}
		
	}
	
	@GetMapping("/usuarioNormal")
	public String vista(Model model) {
		return "usuarioNormal";
	}
	
	@PostMapping("/addEmpresa1")
	public String submit(@Valid @ModelAttribute("empresaForm") Empresa empresa,
			BindingResult bindingResult, Model model, Usuario user){
		/*if(user != null && user.getTipoUser() == 0) {
			return "redirect:/app/usuarioNormal";
		}else {*/
			
			model.addAttribute("Empresa", empresa);
			empresaSE.add(empresa);
		
		
		return "redirect:/app/empresas";
		//}
		
			
	}
	
	@GetMapping("/formEditarEmpresa/{id}")
	public String FormularioEditar(@PathVariable("id") Long id, Model model) {
		Empresa empresa = empresaSE.findById(id);
		model.addAttribute("empresaForm", empresa);
		return "formEditarEmpresa";
	}

	@PostMapping("/{id}/editar")
	public String submitEditar(@ModelAttribute("empresaForm") Empresa empresa,BindingResult bindingResult, Model model) {
			
		empresaSE.add(empresa);
		
		
		return "redirect:/app/empresas";
	}
	
	@GetMapping("/eliminarEmpresa/{id}")
	public String eliminarEmpresa(@PathVariable("id")long id, Model model){
		empresaSE.deleteEmpresa(id);
		return "redirect:/app/empresas";
	}
	
	
}

package com.gestool.controller;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

import com.gestool.formbean.FormularioLogin;
import com.gestool.model.Usuario;
import com.gestool.services.UsuarioService;


@Controller
public class UsuarioController {
	
	
	@Autowired
	UsuarioService usuarioSE;
	
	@Autowired
	HttpSession session;
	

	@GetMapping({"/", "/login"})
	public String showLogin(Model model) {
		model.addAttribute("loginForm", new FormularioLogin());
		return "login";
				
	}
	
	@PostMapping("/doLogin")
	public String doLogin(@ModelAttribute("loginForm") FormularioLogin formularioLogin, BindingResult bindingResult, Model model) {
		
		Usuario user = usuarioSE.loginByEmailAndPassword(formularioLogin.getEmail(), formularioLogin.getPassword());
		if (user != null & user.getTipoUser() == 0) {
			session.setAttribute("usuarioActual", user);
			return "redirect:/app/usuarioNormal";
		}else if (user != null & user.getTipoUser()==1) {
			
			session.setAttribute("usuarioActual", user);
			return "redirect:/app/empresas";
		} else {
			model.addAttribute("error", "El usuario o contraseña no es válido");
			return "login";
		}
		
	}
	
	@GetMapping("/logout")
	public String doLogout(Model model) {
		session.setAttribute("usuarioActual", null);
		return "redirect:/";
	}
	
}

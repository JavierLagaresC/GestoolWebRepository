package com.gestool.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "usuarios")
public class Usuario implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	private String uuid;
	private String nombre;
	private String email;
	private String password;
	private String remember_token;
	@Column(name = "super_user")
	private Integer tipoUser;
	/*@OneToOne(cascade = CascadeType.ALL, mappedBy = "uuid")
	@JoinColumn(name ="uuid")*/
	private String rol_uuid;
	private Date created_at;
	private Date updated_at;
	
	public Usuario() {
		
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getUuid() {
		return uuid;
	}

	public void setUuid(String uuid) {
		this.uuid = uuid;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getRemember_token() {
		return remember_token;
	}

	public void setRemember_token(String remember_token) {
		this.remember_token = remember_token;
	}

	

	/*public int getTipo_user() {
		return tipo_user;
	}

	public void setTipo_user(int tipo_user) {
		this.tipo_user = tipo_user;
	}*/

	public String getRol_uuid() {
		return rol_uuid;
	}

	public Integer getTipoUser() {
		return tipoUser;
	}

	public void setTipoUser(Integer tipoUser) {
		this.tipoUser = tipoUser;
	}

	public void setRol_uuid(String rol_uuid) {
		this.rol_uuid = rol_uuid;
	}
	

	public Date getCreated_at() {
		return created_at;
	}

	/*public Roles getRol_uuid() {
		return rol_uuid;
	}

	public void setRol_uuid(Roles rol_uuid) {
		this.rol_uuid = rol_uuid;
	}*/

	public void setCreated_at(Date created_at) {
		this.created_at = created_at;
	}

	public Date getUpdated_at() {
		return updated_at;
	}

	public void setUpdated_at(Date updated_at) {
		this.updated_at = updated_at;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((created_at == null) ? 0 : created_at.hashCode());
		result = prime * result + ((email == null) ? 0 : email.hashCode());
		result = prime * result + ((id == null) ? 0 : id.hashCode());
		result = prime * result + ((nombre == null) ? 0 : nombre.hashCode());
		result = prime * result + ((password == null) ? 0 : password.hashCode());
		result = prime * result + ((remember_token == null) ? 0 : remember_token.hashCode());
		result = prime * result + ((rol_uuid == null) ? 0 : rol_uuid.hashCode());
		result = prime * result + ((tipoUser == null) ? 0 : tipoUser.hashCode());
		result = prime * result + ((updated_at == null) ? 0 : updated_at.hashCode());
		result = prime * result + ((uuid == null) ? 0 : uuid.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Usuario other = (Usuario) obj;
		if (created_at == null) {
			if (other.created_at != null)
				return false;
		} else if (!created_at.equals(other.created_at))
			return false;
		if (email == null) {
			if (other.email != null)
				return false;
		} else if (!email.equals(other.email))
			return false;
		if (id == null) {
			if (other.id != null)
				return false;
		} else if (!id.equals(other.id))
			return false;
		if (nombre == null) {
			if (other.nombre != null)
				return false;
		} else if (!nombre.equals(other.nombre))
			return false;
		if (password == null) {
			if (other.password != null)
				return false;
		} else if (!password.equals(other.password))
			return false;
		if (remember_token == null) {
			if (other.remember_token != null)
				return false;
		} else if (!remember_token.equals(other.remember_token))
			return false;
		if (rol_uuid == null) {
			if (other.rol_uuid != null)
				return false;
		} else if (!rol_uuid.equals(other.rol_uuid))
			return false;
		if (tipoUser == null) {
			if (other.tipoUser != null)
				return false;
		} else if (!tipoUser.equals(other.tipoUser))
			return false;
		if (updated_at == null) {
			if (other.updated_at != null)
				return false;
		} else if (!updated_at.equals(other.updated_at))
			return false;
		if (uuid == null) {
			if (other.uuid != null)
				return false;
		} else if (!uuid.equals(other.uuid))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "Usuario [id=" + id + ", uuid=" + uuid + ", nombre=" + nombre + ", email=" + email + ", password="
				+ password + ", remember_token=" + remember_token + ", tipoUser=" + tipoUser + ", rol_uuid=" + rol_uuid
				+ ", created_at=" + created_at + ", updated_at=" + updated_at + "]";
	}

	

	
}
